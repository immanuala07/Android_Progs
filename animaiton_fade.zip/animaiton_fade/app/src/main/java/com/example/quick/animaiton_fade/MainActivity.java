package com.example.quick.animaiton_fade;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    Button btnfadein,btnfadeout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnfadein=(Button) findViewById(R.id.fadein);
        btnfadein.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageView image =(ImageView)findViewById(R.id.iv);
                Animation animaiton = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoom_in);
                image.startAnimation(animaiton);
            }
        });
        btnfadeout=(Button) findViewById(R.id.fadeout);
        btnfadeout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ImageView image =(ImageView)findViewById(R.id.iv);
                Animation animaiton = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.rotate_anticlockwise);
                image.startAnimation(animaiton);
            }
        });

    }
}
